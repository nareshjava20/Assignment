package com.kapturecrm.reciver;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.kapturecrm.constant.NotificationConstants;
import com.kapturecrm.dto.Email;
import com.kapturecrm.dto.SMS;

@Component
public class Receiver {
	
	@JmsListener(destination = NotificationConstants.EMAIL_QUEUE, containerFactory = "notificationFactory")
	  public void receiveMessage(Email email) {
	    System.out.println("Received <" + email + ">");
	  }


	  @JmsListener(destination = NotificationConstants.SMS_QUEUE, containerFactory = "notificationFactory")
	  public void smsMessage(SMS sms) {
	    System.out.println("Received <" + sms + ">");
	  }

}
