package com.kapturecrm.service;

import com.kapturecrm.dto.Email;
import com.kapturecrm.dto.NotificationRequest;
import com.kapturecrm.dto.SMS;

public interface NotificationService {

	public void processEmailAndSMS(NotificationRequest notificationRequests);
	
	public void processEmail(Email email);
	
	public void processSms(SMS sms);
}
