package com.kapturecrm.service;

import java.util.List;

import javax.jms.MapMessage;
import javax.print.attribute.standard.Destination;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.kapturecrm.dto.Email;
import com.kapturecrm.dto.NotificationRequest;
import com.kapturecrm.dto.SMS;

@Service
public class NotificationServiceImpl implements NotificationService {

	@Autowired
	private JmsTemplate jmsTemplate;

	@Override
	public void processEmailAndSMS(NotificationRequest notificationRequests) {
		if (!notificationRequests.getEmail().isEmpty())
			for (Email email : notificationRequests.getEmail())
				processEmail(email);
		if (!notificationRequests.getSms().isEmpty())
			for (SMS sms : notificationRequests.getSms())
				processSms(sms);

	}

	@Override
	public void processEmail(Email email) {
		jmsTemplate.convertAndSend("emailQueue", email);
	}

	@Override
	public void processSms(SMS sms) {
		jmsTemplate.convertAndSend("smsQueue", sms);
	}

}
