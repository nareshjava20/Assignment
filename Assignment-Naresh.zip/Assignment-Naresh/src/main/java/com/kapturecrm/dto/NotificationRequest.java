package com.kapturecrm.dto;

import java.util.List;

public class NotificationRequest {

	private List<Email> email;
	private List<SMS> sms;

	public List<Email> getEmail() {
		return email;
	}

	public void setEmail(List<Email> email) {
		this.email = email;
	}

	public List<SMS> getSms() {
		return sms;
	}

	public void setSms(List<SMS> sms) {
		this.sms = sms;
	}

}
