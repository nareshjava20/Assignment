package com.kapturecrm.constant;

public class NotificationConstants {

	public static final String SMS_QUEUE= "smsQueue";
	public static final String EMAIL_QUEUE = "emailQueue";
	public static final String FROM = "from";
	public static final String TO = "to";
	public static final String SUBJECT = "subject";
	public static final String BODY = "body";
	
}
